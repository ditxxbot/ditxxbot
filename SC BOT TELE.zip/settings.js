/*
• Base Ori DitzzXploit
Penting ‼️

Hapus Bagian/Teks Ini? Masuk Neraka Paling Bawah

Script Ini Murni Bikinan Sendiri, Saya Hanya Sekedar Kroco Penghuni Inti Bumi.

Thanks To :                                
- Allah Swt 
- Nabi Muhammad Saw         
- My Parents
*/

const settings = {
  token: '6945559020:AAGUSbyahBRKmqQBXyZgqOTNZiQMu8dFNlA', // Token Bot
  pp: 'https://telegra.ph/file/b0122642e408e60c4d243.jpg',
};

module.exports = settings;